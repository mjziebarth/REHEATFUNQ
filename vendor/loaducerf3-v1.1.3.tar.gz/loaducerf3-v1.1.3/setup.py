# Setup script for the loaducerf3 python module.
#
# Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
#
# Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
#
# This file is part of loaducerf3.
#
# loaducerf3 is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published
# by the Free Software Foundation, either version 3 of the License,
# or (at your option) any later version.
#
# loaducerf3 is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.


# Imports:
from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext as bext
from tempfile import NamedTemporaryFile
import subprocess
import shutil
from pathlib import Path

srcpath = Path(".")

# Custom wrapper to build using Meson and show this
# responsively in the setup process:
class MesonExtension(Extension):
    def __init__(self, name):
        self.mock_source = NamedTemporaryFile(suffix='.cpp')
        super().__init__(name, sources=[self.mock_source.name])

class build_ext(bext):
    def run(self):
        # Layout all the files:
        super().run()

        # Build the Meson library and overwrite the
        # previous empty library file:
        self.build_meson(self.extensions[0])

        # Call again the copy code:
        self.copy_extensions_to_source()

    def build_meson(self, ext):
        # Build the C++/Cython code using the Meson
        # build system:
        subprocess.run(["bash","compile.sh"])

        # Get the file name:
        buildpath = srcpath / "builddir"

        # Find all compiled libraries:
        libs = sorted(buildpath.glob('backend.cpython-*.so'))
        if len(libs) == 0:
            raise RuntimeError("Did not find compiled `backend.pyx`.")

        # Use the highest version (= highest sorting)
        lib = libs[-1]

        # The name from which build_ext copies.
        # We overwrite the empty file therein:
        filename \
            = self.get_ext_filename(
                self.get_ext_fullname(ext.name)
            )
        shutil.copy(lib, Path(self.build_lib) / filename)

backend = MesonExtension("loaducerf3/backend")


# Setup:

setup(
	name='loaducerf3',
	version='1.1.3',
	description="UCERF3 data loading facilities",
	long_description="Convenience functions to load data from the UCERF3 "
	                 "binary data files.",
	author='Malte J. Ziebarth',
	author_email='ziebarth@gfz-potsdam.de',
	packages=['loaducerf3'],
	py_modules=['loaducerf3'],
	provides=['loaducerf3'],
	ext_modules = [backend],
	cmdclass = {
		'build_ext': build_ext
	},
	license='GPL-3.0-or-later',
)
