# Optional matplotlib plotting facilities for the loaducerf3 module.
#
# Copyright (C) 2020-2022 Deutsches GeoForschungsZentrum Potsdam
#
# Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
#
# This file is part of loaducerf3.
#
# loaducerf3 is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published
# by the Free Software Foundation, either version 3 of the License,
# or (at your option) any later version.
#
# loaducerf3 is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with loaducerf3. If not, see <https://www.gnu.org/licenses/>

import numpy as np
from .backend import UCERF3Model
from matplotlib.patches import Polygon
from matplotlib.collections import LineCollection
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from typing import Tuple

def model_to_collection(model: UCERF3Model, cmap = 'inferno',
                        norm=Normalize, color=None, **kwargs) -> LineCollection:
    """
    Creates a LineCollection that can be added to
    a matplotlib Axes.
    """
    lines = []
    powers = []
    for fs in model.fault_segments():
        coords = fs.coordinates()
        lines.append(coords)
        powers.append(fs.power())

    # Color the lines according to the segment power:
    if cmap is not None:
        if color is not None:
            raise RuntimeError("`cmap` and `color` cannot be used "
                               "simultaneously!")
        norm = norm(min(powers), max(powers))
        colors = ScalarMappable(norm,cmap=cmap).to_rgba(powers)
    elif color is not None:
        colors = color
    else:
        colors = 'k'

    return LineCollection(lines, colors=colors, **kwargs)


def plot_model(ax, model: UCERF3Model, adjust_limits=True, **kwargs):
    """
    Plot a UCERF3Model instance on an axis.

    Keyword arguments:
       adjust_limits : If true, rescale the axes limits to fit the data.
    """
    lc = model_to_collection(model, **kwargs)
    if adjust_limits:
        xmin = np.inf
        xmax = -np.inf
        ymin = np.inf
        ymax = -np.inf
        for path in lc.get_paths():
            xmin = min(path.vertices[:,0].min(),xmin)
            xmax = max(path.vertices[:,0].max(),xmax)
            ymin = min(path.vertices[:,1].min(),ymin)
            ymax = max(path.vertices[:,1].max(),ymax)

        if ax.has_data():
            xlim = ax.get_xlim()
            ylim = ax.get_ylim()
            xmin = min(xmin,xlim[0])
            xmax = max(xmax,xlim[1])
            ymin = min(ymin,ylim[0])
            ymax = max(ymax,ylim[1])

        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)

    ax.add_collection(lc)
