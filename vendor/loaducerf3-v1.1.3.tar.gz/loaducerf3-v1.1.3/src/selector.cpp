/*
 * Point selection based on geometric relations.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */
#include <../include/selector.hpp>
#include <stdexcept>

using loaducerf3::geo_t;
using loaducerf3::xy_t;
using loaducerf3::Polygon;
using loaducerf3::CircularSelector;
using loaducerf3::PolygonSelector;


//CircularSelector::CircularSelector()
//{
//}

CircularSelector::CircularSelector(double lon, double lat, double radius_m)
   : center(deg2rad(lon), deg2rad(lat)), r_m(radius_m)
{
}

CircularSelector::CircularSelector(const geo_t& center, double radius_m)
   : center(center), r_m(radius_m)
{
}

bool CircularSelector::operator()(const geo_t& pt) const
{
	return false;
}








PolygonSelector::PolygonSelector()
{
}

PolygonSelector::PolygonSelector(Polygon&& poly)
    : poly(poly)
{
}

PolygonSelector::PolygonSelector(const Polygon& poly)
    : poly(poly)
{
}

bool PolygonSelector::operator()(const xy_t& point) const
{
	return poly.contains(point);
}

bool PolygonSelector::select(double x, double y) const
{
	xy_t point(x, y);
	return poly.contains(point);
}
