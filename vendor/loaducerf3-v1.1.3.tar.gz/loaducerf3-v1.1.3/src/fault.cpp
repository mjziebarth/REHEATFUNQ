/*
 * A UCERF3 fault.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <../include/fault.hpp>

using loaducerf3::xy_t;
using loaducerf3::Fault;
using loaducerf3::ProjectedFaultSegment;

static std::vector<xy_t> \
compute_trace(const std::vector<const ProjectedFaultSegment*>& segments)
{
	std::vector<xy_t> trace;
	for (auto seg : segments){
		for (const xy_t& xy : *seg){
			trace.push_back(xy);
		}
	}

	return trace;
}


static double
compute_length(const std::vector<xy_t>& trace)
{
	if (trace.size() < 2)
		return 0.0;

	double L = 0.0;
	auto it = trace.begin();
	auto last = it;
	for (++it; it != trace.end(); ++it){
		L += last->distance(*it);
		last = it;
	}
	return L;
}


static double
compute_area(const std::vector<const ProjectedFaultSegment*>& segments)
{
	double A = 0.0;
	for (auto seg: segments)
		A += seg->area();
	return A;
}


static double
compute_power(const std::vector<const ProjectedFaultSegment*>& segments)
{
	double P = 0.0;
	for (auto seg: segments)
		P += seg->power();
	return P;
}


Fault::Fault(const std::string& name,
             std::vector<const ProjectedFaultSegment*>&& segments)
    : _name(name), _segments(segments), _trace(compute_trace(_segments)),
      _length(compute_length(_trace)), _area(compute_area(_segments)),
      _power(compute_power(_segments))
{
}
