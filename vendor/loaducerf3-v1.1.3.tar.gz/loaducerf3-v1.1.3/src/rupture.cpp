/*
 * One rupture spanning a set of UCERF3 fault segments.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <../include/rupture.hpp>
#include <../include/binary.hpp>
#include <../include/physics.hpp>
#include <fstream>
#include <optional>
#include <iostream>
#include <cmath>

using loaducerf3::Rupture;
using loaducerf3::read_double;
using loaducerf3::read_int;
using loaducerf3::mag2energy;
using std::ifstream;


Rupture::Rupture(std::vector<unsigned int>&& sec, double mag, double rate,
                  double rup_area, double rup_len)
    : mag(mag), _rate(rate), rup_area(rup_area), rup_len(rup_len), sec(sec),
      _energy(mag2energy(mag))
{
}


static std::optional<Rupture>
read_one(ifstream& magsf, ifstream& ratesf, ifstream& rup_areasf,
         ifstream& rup_lengthsf, ifstream& rup_sectionsf)
{
	/* Read all the simple double properties: */
	double mag, rate, rup_area, rup_length;
	if (!read_double(magsf, mag)){
		return std::optional<Rupture>();
	}

	if (!read_double(ratesf, rate)){
		return std::optional<Rupture>();
	}
	/* Rate is given in 1 / yr: */
	rate *= (1.0 / (365.25 * 24 * 60 * 60));

	if (!read_double(rup_areasf, rup_area)){
		return std::optional<Rupture>();
	}

	if (!read_double(rup_lengthsf, rup_length)){
		return std::optional<Rupture>();
	}

	/* Read the integer list: */
	int size, tmp;
	if (!read_int(rup_sectionsf, size) || size < 0){
		return std::optional<Rupture>();
	}

	std::vector<unsigned int> sections(size);
	for (unsigned int i=0; i < static_cast<unsigned int>(size); ++i){
		if (!read_int(rup_sectionsf, tmp) || tmp < 0){
			return std::optional<Rupture>();
		}
		sections[i] = tmp;
	}

	return Rupture(std::move(sections), mag, rate, rup_area, rup_length);
}




std::vector<Rupture>
Rupture::read(const char* mags_bin, const char* rates_bin,
              const char* rup_areas_bin, const char* rup_lengths_bin,
              const char* rup_sections_bin)
{
	/* Create the file streams: */
	ifstream magsf(mags_bin);
	ifstream ratesf(rates_bin);
	ifstream rup_areasf(rup_areas_bin);
	ifstream rup_lengthsf(rup_lengths_bin);
	ifstream rup_sectionsf(rup_sections_bin);

	/* Read the length from the rup_sections file: */
	int size;
	if (!read_int(rup_sectionsf, size) || size < 0)
		throw std::runtime_error("Could not read rupture_sections_bin.");

	/* Output vector: */
	std::vector<Rupture> res;
	res.reserve(size);

	/* Iterate over the files: */
	std::optional<Rupture> rup;
	while (rup = read_one(magsf, ratesf, rup_areasf, rup_lengthsf,
	                      rup_sectionsf))
	{
		/* Read next: */
		res.emplace_back(std::move(rup.value()));
	}
	if (res.size() != static_cast<size_t>(size))
		throw std::runtime_error("Invalid size combination of the data files.");

	return res;
}


const std::vector<unsigned int>& Rupture::sections() const
{
	return sec;
}


double Rupture::rate() const
{
	return _rate;
}


double Rupture::energy() const
{
	return _energy;
}


double Rupture::power() const
{
	return _rate * _energy;
}


double Rupture::magnitude() const
{
	return mag;
}


double Rupture::rupture_area() const
{
	return rup_area;
}

double Rupture::rupture_length() const
{
	return rup_len;
}
