/*
 * Two-dimensional polygons and containment therein. Uses CGAL to
 * compute the containment.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */
#include <../include/polygon.hpp>

using loaducerf3::PolygonError;
using loaducerf3::Polygon;
using loaducerf3::xy_t;

PolygonError::PolygonError(const char* msg) : std::runtime_error(msg)
{
}

Polygon::Polygon() : is_simple(false)
{
}

Polygon::Polygon(const std::vector<xy_t>& points)
{
	for (const xy_t& xy : points)
		poly.push_back(Point(xy.x, xy.y));
	if (!poly.is_simple())
		throw PolygonError("Polygon is not simple after construction using "
		                   "vector<xy_t>.");
	is_simple = true;
}

Polygon::Polygon(const double* x, const double* y, size_t n)
{
	for (size_t i=0; i<n; ++i)
		poly.push_back(Point(x[i], y[i]));
	if (!poly.is_simple())
		throw PolygonError("Polygon is not simple after construction using "
		                   "double pointers.");
	is_simple = true;
}

bool Polygon::contains(const xy_t& point) const
{
	if (!is_simple)
		throw PolygonError("Polygon is not simple in contains()!");

	switch (poly.bounded_side(Point(point.x, point.y))) {
		case CGAL::ON_BOUNDED_SIDE :
			return true;
		case CGAL::ON_BOUNDARY:
			return true;
		case CGAL::ON_UNBOUNDED_SIDE:
			return false;
	}
	return false;
}
