/*
 * Reading the binary UCERF3 files.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <../include/binary.hpp>

using std::ifstream;

bool loaducerf3::read_double(ifstream& ifs, double& out){
	/* Read the 8 bytes: */
	union {
		char bytes[8];
		double d;
	};

	for (int i=0; i<8; ++i){
		bytes[7-i] = ifs.get();
		if (!ifs)
			return false;
	}

	out = d;
	return true;
}

bool loaducerf3::read_int(ifstream& ifs, int& out){
	/* Read the 4 bytes: */
	union {
		char bytes[4];
		int j;
	};

	for (int i=0; i<4; ++i){
		bytes[3-i] = ifs.get();
		if (!ifs)
			return false;
	}

	out = j;
	return true;
}

bool loaducerf3::read_double_array(std::ifstream& ifs, std::vector<double>& out)
{
	/* Read the length: */
	int n;
	if (!read_int(ifs, n) || n < 0)
		return false;

	/* Now read the number of doubles: */
	out.resize(n);
	for (unsigned int i=0; i < static_cast<unsigned int>(n); ++i){
		if (!read_double(ifs, out[i]))
			return false;
	}

	return true;
}
