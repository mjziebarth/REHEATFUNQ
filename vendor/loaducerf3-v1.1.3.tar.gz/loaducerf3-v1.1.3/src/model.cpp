/*
 * A wrapper for a UCERF3 model.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <../include/model.hpp>
#include <../include/binary.hpp>
#include <../include/numeric.hpp>
#include <fstream>
#include <cmath>
#include <map>

using projwrapper::PI;
using loaducerf3::xy_t;
using loaducerf3::geo_t;
using loaducerf3::Fault;
using loaducerf3::Rupture;
using loaducerf3::read_double;
using loaducerf3::UCERF3Model;
using loaducerf3::ProjWrapper;
using loaducerf3::FaultSegment;
using loaducerf3::AllSelector;
using loaducerf3::GridSources;
using loaducerf3::PolygonSelector;
using loaducerf3::slip_weight_type;
using loaducerf3::CircularSelector;
using loaducerf3::integrate_sqrt_sin;
using loaducerf3::ProjectedFaultSegment;
using loaducerf3::segment_selection_policy;
using std::fmin;
using std::fabs;

/*
 *    Local helper functions:
 */

template<typename T>
T conditional_project(const geo_t&, const ProjWrapper& proj);


template<>
geo_t conditional_project(const geo_t& pt, const ProjWrapper& proj)
{
	return pt;
}

template<>
xy_t conditional_project(const geo_t& pt, const ProjWrapper& proj)
{
	return proj.project(pt);
}

template<typename selector_t>
bool select_point(const geo_t& pt, const selector_t& selector,
                  const ProjWrapper& proj)
{
	typedef typename selector_t::coordinate_t crds_t;

	return selector(conditional_project<crds_t>(pt, proj));
}


template<typename selector_t>
std::vector<FaultSegment>
select_fault_segments(const char* fault_section_xml, const selector_t& selector,
                      const ProjWrapper& proj, segment_selection_policy ssp)
{
	/* A lambda function conditional on the  */
	if (ssp == loaducerf3::ALL_IN){
		auto seg_selector = [&](const FaultSegment& seg) -> bool {
			for (const geo_t& pt : seg){
				if (!select_point<selector_t>(pt, selector, proj))
					return false;
			}
			return true;
		};
		return FaultSegment::parse_xml(fault_section_xml, seg_selector);

	} else if (ssp == loaducerf3::ANY_IN){
		auto seg_selector = [&](const FaultSegment& seg) -> bool {
				for (const geo_t& pt : seg){
					if (select_point<selector_t>(pt, selector, proj))
						return true;
				}
				return false;
		};
		return FaultSegment::parse_xml(fault_section_xml, seg_selector);

	} else {
		throw std::runtime_error("Unknown segment_selection_policy.");
	}
}


template<typename selector_t>
void conditionally_compute_mask_geo(const std::vector<FaultSegment>& segments,
                                    std::vector<bool>& segment_mask,
                                    const selector_t& selector,
                                   segment_selection_policy ssp);

template<>
void conditionally_compute_mask_geo(const std::vector<FaultSegment>& segments,
                                    std::vector<bool>& segment_mask,
                                    const CircularSelector& selector,
                                   segment_selection_policy ssp)
{
	/* Do something! */
}

template<>
void conditionally_compute_mask_geo(const std::vector<FaultSegment>& segments,
                                    std::vector<bool>& segment_mask,
                                    const PolygonSelector& selector,
                                   segment_selection_policy ssp)
{
}

template<>
void conditionally_compute_mask_geo(const std::vector<FaultSegment>& segments,
                                    std::vector<bool>& segment_mask,
                                    const AllSelector& selector,
                                   segment_selection_policy ssp)
{
}

template<typename selector_t>
void conditionally_compute_mask_xy(
             const std::vector<ProjectedFaultSegment>& segments,
             std::vector<bool>& segment_mask,
             const selector_t& selector,
             segment_selection_policy ssp
);

template<>
void conditionally_compute_mask_xy(
             const std::vector<ProjectedFaultSegment>& segments,
             std::vector<bool>& segment_mask,
             const CircularSelector& selector,
             segment_selection_policy ssp)
{
}

template<>
void conditionally_compute_mask_xy(
             const std::vector<ProjectedFaultSegment>& segments,
             std::vector<bool>& segment_mask,
             const PolygonSelector& selector,
             segment_selection_policy ssp)
{
	if ((ssp != loaducerf3::ALL_IN) && (ssp != loaducerf3::ANY_IN))
		throw std::runtime_error("Unknown segment_selection_policy.");

	auto select_segment = [&](const ProjectedFaultSegment& seg) -> bool
	{
		if (ssp == loaducerf3::ALL_IN){
			for (const xy_t& pt : seg){
				if (!selector(pt))
					return false;
			}
			return true;

		} else if (ssp == loaducerf3::ANY_IN){
				for (const xy_t& pt : seg){
					if (selector(pt))
						return true;
				}
				return false;
		}
	};

	auto bit = segment_mask.begin();
	for (auto it=segments.begin(); it != segments.end(); ++it){
		*bit = select_segment(*it);
		++bit;
	}
}

template<>
void conditionally_compute_mask_xy(
            const std::vector<ProjectedFaultSegment>& segments,
            std::vector<bool>& segment_mask,
            const AllSelector& selector,
            segment_selection_policy ssp)
{
}



template<typename selector_t>
static std::vector<ProjectedFaultSegment>
process_fault_segments(std::vector<FaultSegment>&& segments,
                       const char* sect_areas_bin, const ProjWrapper& proj,
                       std::vector<Rupture>& ruptures,
                       const selector_t& selector, bool use_slip, bool use_area,
                       bool consider_intersegment_distance,
                       bool consider_masked_segments,
                       bool drop_incomplete_ruptures,
                       slip_weight_type slip_weighting,
                       segment_selection_policy ssp)
{
	/* Some variables used later: */
	const size_t N = segments.size();

	/* Compute the segment areas: */
	if (sect_areas_bin){
		double area;
		std::ifstream ifs(sect_areas_bin);
		for (FaultSegment& seg : segments){
			if (!read_double(ifs, area)){
				throw std::runtime_error("The number of elements in "
					                     "`sect_areas.bin` does not fit with the "
					                     "number of fault segments read.");
			}
			seg.set_area(area);
		}
	}

	/* Mask of which to keep: */
	std::vector<bool> segment_mask(segments.size(), true);
	std::vector<bool> rupture_mask(ruptures.size(), true);
	conditionally_compute_mask_geo(segments, segment_mask, selector, ssp);

	/* Project the fault segments: */
	std::vector<ProjectedFaultSegment> projseg(segments.size());
	std::transform(segments.cbegin(), segments.cend(), projseg.begin(),
		[&](const FaultSegment& seg) -> ProjectedFaultSegment {
			return ProjectedFaultSegment(seg, proj);
		}
	);

	conditionally_compute_mask_xy(projseg, segment_mask, selector, ssp);

	/* Number of segments to keep: */
	unsigned int n_segments = 0;
	for (bool b : segment_mask){
		if (b)
			++n_segments;
	}

	/*
	 * Stage 2:
	 *
	 * We have computed the mask.
	 * Nevertheless, the following code still needs the information of
	 * all of the ruptures.
	 */

	/* Compute segment lengths and endpoints: */
	struct segment_data_t {
		double length;
		xy_t x0;
		xy_t x1;
	};
	std::vector<segment_data_t> segment_data((use_slip) ? N : 0);
	if (use_slip){
		for (size_t i=0; i<N; ++i){
			auto it = projseg[i].begin();
			if (it == projseg[i].end())
				throw std::runtime_error("Empty fault segment found.");
			segment_data[i].x0 = *projseg[i].begin();
			segment_data[i].x1 = *(projseg[i].end()-1);
			segment_data[i].length = projseg[i].length();
		}
	}

	/* Value of the sqrt(sin(x)) integral from 0 to pi/2: */
	constexpr double ytot = 2.39628046947118441487984421;

	/* Link them to the ruptures: */
	struct rup_dat{
		double pos_along_rup;
		double w;
	};
	std::vector<rup_dat> rup_seg_dat(0);
	long r_in = -1; // Rupture index (all ruptures).
	long r_out = 0; // Rupture index (outgoing, all with positive mask)
	for (const Rupture& rup : ruptures){
		++r_in;
		const std::vector<unsigned int>& secs_r(rup.sections());
		const size_t S = secs_r.size();
		rup_seg_dat.resize(S);

		/* Compute the total rupture length and how it distributes among
		 * the fault segments */
		double dist = 0.0;
		double zl = 0.0;
		if (use_slip && S > 0){
			/* First segment starts at coordinate 0 along the rupture: */
			auto piter = rup_seg_dat.begin();
			piter->pos_along_rup = 0.0;

			++piter;
			auto last(secs_r.begin());
			dist += segment_data[*last].length;
			for (auto it=last+1; it != secs_r.end(); ++it){
				/* The total rupture length is the sum of the rupture lengths
				 * of all the ruptures segments, as well as potentiallys the
				 * distances between the segment ends. */
				const segment_data_t& s0(segment_data[*last]);
				const segment_data_t& s1(segment_data[*it]);
				dist += s1.length;
				if (consider_intersegment_distance){
					/* Compute the minimum distance between an end segment
					 * of the last fault and one of the new: */
					double ddist = std::sqrt(fmin(fmin(
					                         s1.x0.distance_squared(s0.x0),
					                         s1.x0.distance_squared(s0.x1)),
					                         fmin(
					                         s1.x1.distance_squared(s0.x0),
					                         s1.x1.distance_squared(s0.x1))));

					/* Assign half the intersegment distance to each segment
					 * by placing the transition point to the middle:
					 */
					piter->pos_along_rup = dist + 0.5 * ddist;
					dist += ddist;
				} else {
					piter->pos_along_rup = dist;
				}
				++piter;
			}
		}

		/* Compute the weight: */
		double W = 0.0;
		bool rup_invalid = false;
		unsigned int n_seg = 0;
		auto piter = rup_seg_dat.begin();
		for (unsigned int i : secs_r){
			/* Compute the running integral of the slip distribution if slip
			 * should be considered. We need to keep track of this even in
			 * case that we skip segment i.
			 */
			if (use_slip && dist > 0.0){
				const double pos = piter->pos_along_rup;
				if (slip_weighting == loaducerf3::TAPERED){
					/* Rupture length in unified coordinates [0,PI]: */
					const double xl = fmax(fmin(PI * pos / dist, PI), 0.0);

					/* Compute the normed sqrt(sin(x)) integral: */
					zl = integrate_sqrt_sin(xl) / ytot;
				} else if (slip_weighting == loaducerf3::UNIFORM) {
					/* */
					zl = pos / dist;
				}
			}

			/* The logic how to continue if the mask is not set: */
			if (segment_mask[i]){
				++n_seg;
			} else {
				if (drop_incomplete_ruptures){
					/* The rupture has at least one incomplete segment.
					 * Drop it and continue with the next rupture (outer
					 * loop). */
					rup_invalid = true;
					break;
				} else if (!consider_masked_segments){
					/* If masked segments are not considered, the remainder
					 * of this loop is skipped. The remainder is what could
					 * be "considered". */
					++piter;
					continue;
				}
			}

			/* For considered segments, compute the weight. */
			double w = 1.0;
			if (use_slip)
				w *= zl;
			if (use_area)
				w *= projseg[i].area();
			piter->w = w;
			W += w;

			++piter;
		}

		/* See if we drop the rupture: */
		if ((rup_invalid && drop_incomplete_ruptures) || W == 0.0 || n_seg == 0)
		{
			rupture_mask[r_in] = false;
			continue;
		}

		/* Now finalize the weights and distribute the rate accordingly: */
		for (unsigned int j=0; j<S; ++j){
			const unsigned int i = secs_r[j];
			if (!segment_mask[i])
				continue;

			double w = rup_seg_dat[j].w / W;
			projseg[i].add_rupture_link(r_out, w);
			projseg[i].add_power(rup.power() * w);
		}
		++r_out;
	}

	/* Apply the masks, updating the indices of the
	 * ruptures: */
	constexpr unsigned int max_uint
	   = std::numeric_limits<unsigned int>::max();
	std::vector<unsigned int> s2snew(projseg.size(), max_uint);
	std::vector<ProjectedFaultSegment> segments_masked;
	segments_masked.reserve(n_segments);
	auto bit = segment_mask.cbegin();
	auto s2sit = s2snew.begin();
	for (auto it=projseg.cbegin(); it != projseg.cend(); ++it){
		if (*bit){
			/* Found a valid fault segment. Set the ID transform
			 * and keep the segment: */
			*s2sit = segments_masked.size();
			segments_masked.push_back(*it);
		}
		++s2sit;
		++bit;
	}
	projseg.swap(segments_masked);
	segments_masked.clear();

	std::vector<Rupture> ruptures_masked;
	ruptures_masked.reserve(r_out);
	bit = rupture_mask.cbegin();
	for (auto it=ruptures.cbegin(); it != ruptures.cend(); ++it){
		if (*bit){
			std::vector<unsigned int> sec_r;;
			for (unsigned int i : it->sections()){
				if (segment_mask[i]){
					i = s2snew[i];
					sec_r.push_back(i);
					if (i == max_uint)
						throw std::runtime_error("Problem in the segment "
						                         "index remapping!");
				}
			}
			sec_r.shrink_to_fit();
			ruptures_masked.emplace_back(std::move(sec_r), it->magnitude(),
			                             it->rate(), it->rupture_area(),
			                             it->rupture_length());
		}
		++bit;
	}
	ruptures.swap(ruptures_masked);
	ruptures_masked.clear();

	return projseg;
}



static std::shared_ptr<const ProjWrapper>&
assure_not_null(std::shared_ptr<const ProjWrapper>& proj)
{
	if (!proj)
		throw std::runtime_error("ProjWrapper not inizialized.");
	return proj;
}


template<typename select_t>
GridSources
read_grid_sources(const char* relm_gridded_region_csv,
                  const char* grid_sources_bin,
                  const select_t& selector, const ProjWrapper& proj);


template<>
GridSources
read_grid_sources(const char* relm_gridded_region_csv,
                  const char* grid_sources_bin,
                  const AllSelector& select, const ProjWrapper& proj)
{
	auto selectfun = [=](const geo_t&, const xy_t&) -> bool {
		return true;
	};
	return GridSources(relm_gridded_region_csv, grid_sources_bin,
	                   selectfun, proj);
}


template<>
GridSources
read_grid_sources(const char* relm_gridded_region_csv,
                  const char* grid_sources_bin,
                  const PolygonSelector& select, const ProjWrapper& proj)
{
	auto selectfun = [&](const geo_t&, const xy_t&xy) -> bool {
		return select(xy);
	};
	return GridSources(relm_gridded_region_csv, grid_sources_bin,
	                   selectfun, proj);
}


template<>
GridSources
read_grid_sources(const char* relm_gridded_region_csv,
                  const char* grid_sources_bin,
                  const CircularSelector& select, const ProjWrapper& proj)
{
	auto selectfun = [&](const geo_t& laphi, const xy_t&) -> bool {
		return select(laphi);
	};
	return GridSources(relm_gridded_region_csv, grid_sources_bin,
	                   selectfun, proj);
}



/*
 *    The UCERF3Model constructors:
 */

UCERF3Model::UCERF3Model(const char* fault_section_xml,
                         const char* mags_bin, const char* rates_bin,
                         const char* rup_areas_bin, const char* rup_lengths_bin,
                         const char* rup_sections_bin,
                         const char* sect_areas_bin,
                         const char* grid_sources_bin,
                         const char* relm_gridded_region_csv,
                         std::shared_ptr<const ProjWrapper> proj,
                         bool use_slip, bool use_area,
                         bool consider_intersegment_distance,
                         slip_weight_type slip_weighting)
    : proj(assure_not_null(proj)),
      ruptures(Rupture::read(mags_bin, rates_bin, rup_areas_bin,
                             rup_lengths_bin, rup_sections_bin)),
      _segments(process_fault_segments(
                    FaultSegment::parse_xml(fault_section_xml),
                    sect_areas_bin, *proj, ruptures, AllSelector(),
                    use_slip, use_area, consider_intersegment_distance,
                    false, false, slip_weighting, ANY_IN)),
      grdsrc(read_grid_sources(relm_gridded_region_csv,
                               grid_sources_bin, AllSelector(), *proj)),
      _total_power(compute_total_power())
{
	initialize_faults();
}


UCERF3Model::UCERF3Model(const char* fault_section_xml,
                         const char* mags_bin, const char* rates_bin,
                         const char* rup_areas_bin, const char* rup_lengths_bin,
                         const char* rup_sections_bin,
                         const char* sect_areas_bin,
                         const char* grid_sources_bin,
                         const char* relm_gridded_region_csv,
                         const CircularSelector& selector,
                         std::shared_ptr<const ProjWrapper> proj,
                         segment_selection_policy ssp,
                         bool use_slip, bool use_area,
                         bool consider_intersegment_distance,
                         bool consider_masked_segments,
                         bool drop_incomplete_ruptures,
                         slip_weight_type slip_weighting)
    : proj(assure_not_null(proj)),
      ruptures(Rupture::read(mags_bin, rates_bin, rup_areas_bin,
                             rup_lengths_bin, rup_sections_bin)),
      _segments(process_fault_segments(
                    FaultSegment::parse_xml(fault_section_xml),
                    sect_areas_bin, *proj, ruptures, selector,
                    use_slip, use_area, consider_intersegment_distance,
                    consider_masked_segments, drop_incomplete_ruptures,
                    slip_weighting, ssp)),
      grdsrc(read_grid_sources(relm_gridded_region_csv, grid_sources_bin,
                               selector, *proj)),
      _total_power(compute_total_power())
{
	initialize_faults();
}


UCERF3Model::UCERF3Model(const char* fault_section_xml,
                         const char* mags_bin, const char* rates_bin,
                         const char* rup_areas_bin, const char* rup_lengths_bin,
                         const char* rup_sections_bin,
                         const char* sect_areas_bin,
                         const char* grid_sources_bin,
                         const char* relm_gridded_region_csv,
                         const PolygonSelector& selector,
                         std::shared_ptr<const ProjWrapper> proj,
                         segment_selection_policy ssp,
                         bool use_slip, bool use_area,
                         bool consider_intersegment_distance,
                         bool consider_masked_segments,
                         bool drop_incomplete_ruptures,
                         slip_weight_type slip_weighting)
    : proj(assure_not_null(proj)),
      ruptures(Rupture::read(mags_bin, rates_bin, rup_areas_bin,
                             rup_lengths_bin, rup_sections_bin)),
      _segments(process_fault_segments(
                    FaultSegment::parse_xml(fault_section_xml),
                    sect_areas_bin, *proj, ruptures, selector,
                    use_slip, use_area, consider_intersegment_distance,
                    consider_masked_segments, drop_incomplete_ruptures,
                    slip_weighting, ssp)),
      grdsrc(read_grid_sources(relm_gridded_region_csv, grid_sources_bin,
                               selector, *proj)),
      _total_power(compute_total_power())
{
	initialize_faults();
}


const std::vector<ProjectedFaultSegment>& UCERF3Model::segments() const
{
	return _segments;
}


const std::vector<Fault>& UCERF3Model::faults() const
{
	return _faults;
}


double UCERF3Model::total_power() const
{
	return _total_power;
}

const ProjWrapper& UCERF3Model::projection() const
{
	if (!proj)
		throw std::runtime_error("ProjWrapper in UCERF3Model not properly "
		                         "initialized when trying to access it.");
	return *proj;
}


double UCERF3Model::compute_total_power() const {
	double power = 0.0;
	/* Fault segment power: */
	for (const ProjectedFaultSegment& seg : _segments){
		power += seg.power();
	}

	/* Add the grid sources power: */
	power += grdsrc.total_power();

	return power;
}


void UCERF3Model::initialize_faults() {
	/* A map of fault names to sections: */
	std::map<std::string, std::vector<const ProjectedFaultSegment*>>
	    fault2seg;

	for (const ProjectedFaultSegment& seg : _segments){
		auto it = fault2seg.find(seg.parent());
		if (it == fault2seg.end()){
			/* Add new fault: */
			auto it2 = fault2seg.emplace(seg.parent(),
			                       std::vector<const ProjectedFaultSegment*>()
			           );
			if (!it2.second){
				std::string msg("Could not emplace into map (");
				msg += __FILE__;
				msg += ", l.";
				msg += std::to_string(__LINE__);
				msg += ")";
				throw std::runtime_error(msg);
			}
			it = it2.first;
		}
		it->second.push_back(&seg);
	}

	_faults.reserve(fault2seg.size());
	for (auto it : fault2seg){
		std::vector<const ProjectedFaultSegment*> v;
		v.swap(it.second);
		_faults.emplace_back(it.first, std::move(v));
	}
	//Fault::Fault(const std::string& name,
	//             std::vector<const ProjectedFaultSegment*>&& segments)
}

