/*
 *  Physics equations.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <../include/physics.hpp>
#include <cmath>

double loaducerf3::mag2energy(double M)
{
	/*
	 *  Uses the expression
	 *      E = 10 ^ (1.5 * M + 4.8)
	 */
	constexpr double a = std::log(10) * 1.5;
	constexpr double b = std::pow(10, 4.8);
	return std::exp(a*M) * b;
}
