/*
 * Fault segments.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <rapidxml.hpp>
#include <../include/faultsegment.hpp>

using loaducerf3::FaultSegment;
using loaducerf3::FaultSegmentBase;
using loaducerf3::ProjectedFaultSegment;
using loaducerf3::FaultSectionsParseError;
using loaducerf3::deg2rad;
using rapidxml::xml_document;
using rapidxml::xml_node;
using rapidxml::xml_attribute;


FaultSectionsParseError::FaultSectionsParseError(const char* msg)
   : std::runtime_error(msg)
{
}

/*
 * Base class of the fault segments:
 */
FaultSegmentBase::FaultSegmentBase()
{
}


FaultSegmentBase::FaultSegmentBase(unsigned int id, std::string name,
                           double slip_rate_m_s, double slip_rate_std_m_s,
                           double dip, double rake, double upper_depth_m,
                           double lower_depth_m, double aseismic_slip_factor,
                           double coupling, double dip_dir,
                           std::string&& parent_name, unsigned int parent_id,
                           bool connector)
    : id(id), _name(name), slip_rate_m_s(slip_rate_m_s),
      slip_rate_std_m_s(slip_rate_std_m_s), dip(dip), rake(rake),
      upper_depth_m(upper_depth_m), aseismic_slip_factor(aseismic_slip_factor),
      coupling(coupling), dip_dir(dip_dir), parent_name(std::move(parent_name)),
      parent_id(parent_id), connector(connector), _area(0.0), _power(0.0),
      linked_ruptures(0)
{
}


const std::string& FaultSegmentBase::name() const
{
	return _name;
}


const std::string& FaultSegmentBase::parent() const
{
	return parent_name;
}


double FaultSegmentBase::area() const
{
	return _area;
}


void FaultSegmentBase::set_area(double area)
{
	_area = area;
}

double FaultSegmentBase::slip_rate() const
{
	return slip_rate_m_s;
}


double FaultSegmentBase::power() const
{
	return _power;
}


void FaultSegmentBase::add_power(double P)
{
	_power += P;
}


void FaultSegmentBase::add_rupture_link(unsigned int r, double w)
{
	linked_ruptures.push_back({r,w});
}



/*
 * rapidxml attributes to different value types:
 */
static unsigned int attr2uint(const xml_attribute<>* attr)
{
	return std::stoul(std::string(attr->value(), attr->value_size()));
}

static std::string attr2str(const xml_attribute<>* attr)
{
	return std::string(attr->value(), attr->value_size());
}

static double attr2d(const xml_attribute<>* attr)
{
	return std::stod(std::string(attr->value(), attr->value_size()));
}

static bool attr2b(const xml_attribute<>* attr)
{
	return (attr->value_size() > 0) && (attr->value()[0] == 't');
}



static std::vector<char> read_file(std::string file)
{
	/* Read the file into a string: */
	std::ifstream ifs(file);
	std::stringstream sts;
	sts << ifs.rdbuf();
	const std::string text(sts.str());
	std::vector<char> res(text.size()+1);
	std::copy(text.cbegin(), text.cend(), res.begin());
	res.back() = 0;
	return res;
}


std::vector<FaultSegment>
FaultSegment::parse_xml(std::string file,
                     const std::function<bool(FaultSegment const&)>& selector)
{
	/* Some conversions: */
	constexpr double MM_YR = 1e-3 / (365.25 * 24 * 60 * 60);
	constexpr double KM = 1e3;

	/* Read the file to a char buffer: */
	std::vector<char> text(read_file(file));

	/* Setup the parser: */
	xml_document<> doc;
	doc.parse<0>(text.data());

	/* Now parse: */
	std::vector<FaultSegment> segments;
	const xml_node<>* opensha = doc.first_node("OpenSHA");
	if (!opensha)
		throw FaultSectionsParseError("Could not find 'OpenSHA' root node.");
	const xml_node<>* fspd_list = opensha->first_node("FaultSectionPrefDataList");
	if (!fspd_list)
		throw FaultSectionsParseError("Could not find "
		                              "'FaultSectionPrefDataList' section.");
	const xml_node<>* current = fspd_list->first_node();
	while (current){
		/* Decide whether to parse: */
		const xml_attribute<>* attr = current->first_attribute("sectionId");
		if (attr){
			// id
			const unsigned int id = attr2uint(attr);
			// name
			attr = attr->next_attribute("sectionName");
			if (!attr)
				throw FaultSectionsParseError("Did not find 'sectionName' "
				                              "attribute.");
			const std::string name(attr2str(attr));
			// long term slip rate
			attr = attr->next_attribute("aveLongTermSlipRate");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'aveLongTermSlipRate' "
				                              "attribute.");
			const double slip_rate_m_s = attr2d(attr) * MM_YR;
			// std of slip rate
			attr = attr->next_attribute("slipRateStdDev");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'slipRateStdDev' "
				                              "attribute.");
			const double slip_rate_std_m_s = attr2d(attr) * MM_YR;
			// average dip
			attr = attr->next_attribute("aveDip");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'aveDip' "
				                              "attribute.");
			const double dip = attr2d(attr);
			// average rake
			attr = attr->next_attribute("aveRake");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'aveRake' "
				                              "attribute.");
			const double rake = attr2d(attr);
			// average upper depth
			attr = attr->next_attribute("aveUpperDepth");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'aveUpperDepth' "
				                              "attribute.");
			const double upper_depth_m = attr2d(attr) * KM;
			// average lower depth
			attr = attr->next_attribute("aveLowerDepth");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'aveLowerDepth' "
				                              "attribute.");
			const double lower_depth_m = attr2d(attr);
			// aseismic slip factor
			attr = attr->next_attribute("aseismicSlipFactor");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'aseismicSlipFactor' "
				                              "attribute.");
			const double aseismic_slip_factor = attr2d(attr);
			// coupling coefficient
			attr = attr->next_attribute("couplingCoeff");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'couplingCoeff' "
				                              "attribute.");
			const double coupling = attr2d(attr);
			// dip direction
			attr = attr->next_attribute("dipDirection");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'dipDirection' "
				                              "attribute.");
			const double dip_dir = attr2d(attr);
			// parent section name
			attr = attr->next_attribute("parentSectionName");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'parentSectionName' "
				                              "attribute.");
			std::string parent_name(attr2str(attr));
			// parent section id
			attr = attr->next_attribute("parentSectionId");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'parentSectionId' "
				                              "attribute.");
			const unsigned int parent_id = attr2uint(attr);
			// connector
			// average dip
			attr = attr->next_attribute("connector");
			if (!attr)
				throw FaultSectionsParseError("Did not find "
				                              "'connector' "
				                              "attribute.");
			const bool connector = attr2b(attr);

			/* Now read the coordinates: */
			std::vector<geo_t> coords;
			const xml_node<>* ftrace = current->first_node("FaultTrace");
			if (!ftrace)
				throw FaultSectionsParseError("Did not find a FaultTrace node");
			const xml_node<>* point = ftrace->first_node("Location");
			if (!point)
				throw FaultSectionsParseError("'FaultTrace' node did not "
				                              "contain any 'Location' nodes.");
			for (; point; point = point->next_sibling("Location")){
				// Latitude:
				attr = point->first_attribute("Latitude");
				if (!attr)
					throw FaultSectionsParseError("Did not find 'Latitude' "
						                          "attribute in 'Location' "
						                          "node.");
				const double lat = attr2d(attr);
				// dip direction
				attr = attr->next_attribute("Longitude");
				if (!attr)
					throw FaultSectionsParseError("Did not find 'Longitude' "
						                          "attribute in 'Location' "
						                          "node.");
				const double lon = attr2d(attr);
				coords.emplace_back(deg2rad(lon), deg2rad(lat));
			}

			/* Create the fault segment: */
			FaultSegment seg(id, name, slip_rate_m_s, slip_rate_std_m_s, dip,
			                 rake, upper_depth_m, lower_depth_m,
			                      aseismic_slip_factor, coupling, dip_dir,
			                      std::move(parent_name), parent_id, connector,
			                      std::move(coords));

			/* If it passes the filter, emplace: */
			if (selector(seg))
				segments.emplace_back(std::move(seg));

		}
		current = current->next_sibling();
	}
//	std::cout << std::flush;

	return segments;
}


FaultSegment::FaultSegment(unsigned int id, std::string name,
                           double slip_rate_m_s, double slip_rate_std_m_s,
                           double dip, double rake, double upper_depth_m,
                           double lower_depth_m, double aseismic_slip_factor,
                           double coupling, double dip_dir,
                           std::string&& parent_name, unsigned int parent_id,
                           bool connector, std::vector<geo_t>&& coords)
    : FaultSegmentBase(id, name, slip_rate_m_s, slip_rate_std_m_s, dip, rake,
                       upper_depth_m, lower_depth_m, aseismic_slip_factor,
                       coupling, dip_dir, std::move(parent_name), parent_id,
                       connector),
      coords(std::move(coords))
{
}


bool FaultSegment::no_filter(const FaultSegment&)
{
	return true;
}


FaultSegment::const_iterator FaultSegment::begin() const
{
	return coords.cbegin();
}


FaultSegment::const_iterator FaultSegment::end() const
{
	return coords.cend();
}


ProjectedFaultSegment::ProjectedFaultSegment()
{
}

ProjectedFaultSegment::ProjectedFaultSegment(const FaultSegment& other,
                                             const ProjWrapper& proj)
    : FaultSegmentBase(other), coords(other.coords.size()), _length(0.0)
{
	std::transform(other.coords.cbegin(), other.coords.cend(),
	               coords.begin(),
	               [&](const geo_t& p) -> xy_t {
	                   return proj.project(p);
	               });

	/* Compute the length: */
	if (coords.begin() != coords.end()){
		auto it = coords.begin();
		auto last = it;
		++it;
		for (; it != coords.end(); ++it){
			_length += it->distance(*last);
			last = it;
		}
	}
}


ProjectedFaultSegment::const_iterator ProjectedFaultSegment::begin() const
{
	return coords.cbegin();
}


ProjectedFaultSegment::const_iterator ProjectedFaultSegment::end() const
{
	return coords.cend();
}


size_t ProjectedFaultSegment::size() const
{
	return coords.size();
}

double ProjectedFaultSegment::length() const
{
	return _length;
}
