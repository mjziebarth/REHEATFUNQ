/*
 * Grid sources.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <../include/grid.hpp>
#include <../include/physics.hpp>
#include <../include/binary.hpp>
#include <fstream>
#include <algorithm>

using loaducerf3::xy_t;
using loaducerf3::deg2rad;
using loaducerf3::GridError;
using loaducerf3::mag2energy;
using loaducerf3::GridSources;
using loaducerf3::ProjWrapper;
using loaducerf3::read_double;
using loaducerf3::read_int;
using loaducerf3::read_double_array;

#include <iostream>

GridSources::init_mfd_t
GridSources::read_grid_files(const char* relm_gridded_region_csv,
                             const char* grid_sources_bin,
	                         std::function<bool(const geo_t&,
	                                            const xy_t&)> select,
	                         const ProjWrapper& proj,
                             bool skip_header)
{
	/* Read the grid coordinates.
	 * `xy` will afterwards contain the indexed coordinates. */
	struct crds_t {
		size_t id;
		xy_t xy;
		geo_t lola;

		crds_t(size_t id, xy_t&& xy, geo_t&& lola)
		   : id(id), xy(std::move(xy)), lola(std::move(lola))
		{}
	};
	std::vector<crds_t> coords;
	std::ifstream in(relm_gridded_region_csv);
	if (!in.good()){
		std::string msg("Cannot open file \"");
		msg += relm_gridded_region_csv;
		msg += "\"";
		throw GridError(msg);
	}
	std::string line;
	if (skip_header)
		std::getline(in, line); // Skip the header:
	for (std::string line; std::getline(in, line);){
		/* Find the locations of the commas: */
		size_t b0 = line.find(',');
		if (b0 == std::string::npos)
			break;
		size_t b1 = line.find(',',b0+1);
		if (b1 == std::string::npos)
			break;

		/* Convert in between: */
		size_t i = std::stoul(line.substr(0,b0));
		double lat = std::stod(line.substr(b0+1, b1-b0-1));
		double lon = std::stod(line.substr(b1+1, line.size()-b1-1));
		geo_t lola(deg2rad(lon), deg2rad(lat));
		xy_t xy(proj.project(lola));
		coords.emplace_back(i, std::move(xy), std::move(lola));
	}
	in.close();
	std::sort(coords.begin(), coords.end(),
	          [](const crds_t& x,
	             const crds_t& y) -> bool
	          {
	               return x.id < y.id;
	          });

	/* Read the grid sources MFDs: */
	in = std::ifstream(grid_sources_bin);
	if (!in.good()){
		std::string msg("Cannot open file \"");
		msg += grid_sources_bin;
		msg += "\"";
		throw GridError(msg);
	}

	/* First the number of arrays: */
	int n;
	if (!read_int(in, n))
		throw GridError("Could not read number of arrays in grid_sources.bin");
	if ((n < 0) || (static_cast<size_t>(n) != 2 * coords.size() + 1)){
		std::cerr << "n = " << n << "\n";
		std::cerr << "2*crds.size() + 1 = " << 2 * coords.size() + 1 << "\n";
		throw GridError("Number of arrays in grid_sources.bin does not "
		                "correspond to number of grid points in "
		                "relm_gridded_regions.csv");
	}

	/* The result: */
	init_mfd_t res;

	/* Read the magnitudes: */
	if (!read_double_array(in, res.magnitudes))
		throw GridError("Could not read grid sources magnitude array in "
		                "grid_sources.bin");

	/* Read the frequencies: */
	for (size_t i=0; i<coords.size(); ++i){
		mfd_t dat_i;
		dat_i.xy = coords[i].xy;

		if (!read_double_array(in, dat_i.f_unassociated)){
			std::string text("Could not read unassociated frequencies for "
			                 "grid point ");
			text += std::to_string(i);
			text += " in grid_sources.bin";
			throw GridError(text);
		}

		if (!read_double_array(in, dat_i.f_associated)){
			std::string text("Could not read associated frequencies for "
			                 "grid point ");
			text += std::to_string(i);
			text += " in grid_sources.bin";
			throw GridError(text);
		}

		/* Add if to be selected: */
		if (select(coords[i].lola, coords[i].xy)){
			res.freqs.emplace_back(std::move(dat_i));
		}
	}

	/* Scale all the frequencies to SI units: */
	for (mfd_t& freqs : res.freqs){
		for (double& f : freqs.f_unassociated)
			f *= 1.0 / (365.25 * 24 * 60 * 60);
		for (double& f : freqs.f_associated)
			f *= 1.0 / (365.25 * 24 * 60 * 60);
	}

	return res;
}


GridSources::GridSources(const char* relm_gridded_region_csv,
                         const char* grid_sources_bin,
	                     std::function<bool(const geo_t&,
	                                        const xy_t&)> selector,
	                     const ProjWrapper& proj)
    : GridSources(read_grid_files(relm_gridded_region_csv, grid_sources_bin,
                                  selector, proj))
{
}

static std::vector<double> compute_energies(const std::vector<double>& mag)
{
	std::vector<double> E(mag.size());
	auto out = E.begin();
	for (auto in = mag.begin(); in != mag.end(); ++in){
		*out = mag2energy(*in);
		++out;
	}
	return E;
}



GridSources::GridSources(GridSources::init_mfd_t&& init)
    : frequencies(std::move(init.freqs)),
      magnitudes(std::move(init.magnitudes)),
      energies(compute_energies(magnitudes))
{
}

double GridSources::total_power() const
{
	double power = 0.0;
	for (auto mfd : frequencies){
		if (mfd.f_unassociated.size() > 0){
			for (size_t i=0; i<energies.size(); ++i){
				power += mfd.f_unassociated[i] * energies[i];
			}
		}
		if (mfd.f_associated.size() > 0){
			for (size_t i=0; i<energies.size(); ++i){
				power += mfd.f_associated[i] * energies[i];
			}
		}
	}
	return power;
}
