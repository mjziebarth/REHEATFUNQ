import numpy as np
from loaducerf3 import UCERF3Model, UCERF3Files, Polygon, \
                       PolygonSelector

poly = np.array([[-112.29920946,   34.77521341],
                 [-118.36357183,   38.55662923],
                 [-122.12853372,   34.19726774],
                 [-116.19719677,   30.59901394]]
)

proj_str = "proj=omerc lat_0=64.69782150 lonc=-169.71419431 "\
           "alpha=-71.26503909 k_0=0.99959372"

poly = Polygon.from_geographic(poly[:,0], poly[:,1], proj_str)
selector = PolygonSelector(poly)

files = UCERF3Files("FM3_2_NEOK_fault_sections.xml", "FM3_2_NEOK_HB08_mags.bin",
            "FM3_2_NEOK_HB08_DsrTap_CharConst_M5Rate6.5_MMaxOff7.9_NoFix_"
                  "SpatSeisU3_rates.bin",
            "FM3_2_NEOK_rup_areas.bin", "FM3_2_rup_lengths.bin",
            "FM3_2_rup_sections.bin", "FM3_2_NEOK_sect_areas.bin",
            "grid_sources.bin", "relm_gridded_region.csv")

model = UCERF3Model(files, proj_str, selector=selector)

for f in model.faults_with_name("San Andreas"):
    print(f.name())

print("total power of San Andreas:",
      sum(f.power() for f in model.faults_with_name("San Andreas")))
