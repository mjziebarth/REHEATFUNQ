# This file performs a simple command that prints the directory
# of the numpy headers to the shell, which in turn is used in the
# Meson build.
# The command itself is tiny, but the whitespace in 'import numpy'
# has been found to require mutually exclusive syntaxes on
# different machine. Hence, this small script will be called
# from the Meson script.
import numpy
print(numpy.get_include())
