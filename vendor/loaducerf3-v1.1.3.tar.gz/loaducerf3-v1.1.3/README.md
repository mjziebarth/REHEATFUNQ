# The loaducerf3 Python package
C++/Cython-boosted Python methods to load the UCERF3 model.


## Install
The code uses the Meson build system to build the C++/Cython backend code
and Setuptools to install the Python module. A simple way to install the
package is to invoke
```bash
pip install .
```
within the package directory.

The Meson build system can also be invoked separately using
```bash
./compile.sh
```
within the package directory.


## Usage
Before the `loaducerf3` package can be used, the necessary (legacy) UCERF3 files
need to be available. These are `*_fault_sections.xml`, `*_mags.bin`,
`*_rates.bin`, `*_rup_areas.bin`, `*_rup_lengths.bin`, `*_rup_sections.bin`,
`*_sect_areas.bin`, `grid_sources.bin`, and `relm_gridded_region.csv`.
The files are contained in the full compound solution (with the exception of
`relm_gridded_region.csv`) and all files can be downloaded from
[Milner *et al.* (2014)](https://dx.doi.org/10.5281/zenodo.5519802).

The most basic usage is to create a `UCERF3Files` object that captures all of
the required files, and choose a projection that defines the two-dimensional
Euclidean coordinate system which will be worked in (identified by a PROJ
string). Both combined can be used to create a `UCERF3Model` object that loads
all of the data, sets up the network structure between ruptures and fault
segments, and finally computes the average power released on each segment. A
simple example with simplified file names would be the following:
```python
from loaducerf3 import UCERF3Model, UCERF3Files

proj_str = "proj=omerc lat_0=64.6978215 lonc=-169.71419431 "\
           "alpha=-71.26503909 +gamma=-30.62172945 k_0=0.99959372"

files = UCERF3Files("fault_sections.xml", "mags.bin", "rates.bin",
                    "rup_areas.bin", "rup_lengths.bin", "rup_sections.bin",
                    "sect_areas.bin", "grid_sources.bin",
                    "relm_gridded_region.csv")

model = UCERF3Model(files, proj_str)
```
Since fault length computations are performed in the projected Euclidean
coordinate system, it is useful to choose a projection that achieves low
distortion within the investigated area. Here, an oblique Mercator projection
optimized for a set of faults from the UCERF3 model was used.

The `loaducerf3` package gives additional capability to select, based on
location, only a subset of the fault segments within the UCERF3 model.
Currently, the `PolygonSelector` class is implemented that selects fault
segments based on whether they are contained in a polygon in projected space.
A simple example that selects only faults within the polygon defined by the
corners of the region analyzed by
[Ziebarth *et al.* (2020)](https://dx.doi.org/10.1029/2020JB020186) would
augment the above code by the following pieces:
```python
import numpy as np
from loaducerf3 import Polygon, PolygonSelector

crds = np.array([[-112.29920946,   34.77521341],
                 [-118.36357183,   38.55662923],
                 [-122.12853372,   34.19726774],
                 [-116.19719677,   30.59901394]]
)

poly = Polygon.from_geographic(crds[:,0], crds[:,1], proj_str)
selector = PolygonSelector(poly)

model_sub = UCERF3Model(files, proj_str, selector=selector)
```

When a model has been loaded, the (optional) `loaducerf3.plottools` module can
be used to quickly visualize the model:
```python
import matplotlib.pyplot as plt
from loaducerf3.plottools import plot_model

fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_aspect('equal')
plot_model(ax, model, linewidth=0.5, cmap=None, color='gray')
plot_model(ax, model_sub, linewidth=0.8)
```

If a selector is used, ambiguities arise due to the possibility that fault
segments, faults, or ruptures may be intersecting with the selection boundary.
Multiple variants of how to handle the inclusion of intersected fault (segments)
and of how to handle the power distribution of intersected ruptures can be
thought of. The `loaducerf3` module implements a number of them that can be
chosen by using the keyword arguments of the `UCERF3Model` class:

| Keyword                          | Values (default bold)       | Description |
| -------------------------------- | --------------------------- | ----------- |
| `select_if`                      | **`'all'`**,`'any'`         | Select a segment if all/any of its points are selected |
| `use_slip`                       | **`True`**,`False`          | Whether to weight rupture energy distribution to fault segments by slip. |
| `use_area`                       | **`True`**,`False`          | Whether to weight rup. en. di. by fault segment area |
| `consider_intersegment_distance` | **`True`**, `False`         | Whether to consider the distance between fault segments when distributing rupture energy |
| `consider_masked_segments`       | **`True`**, `False`         | Whether to consider masked (i.e. non-selected) segments when distributing rupture energy. If not, any selected rupture energy will be distributed exclusively among selected segments. |
| `drop_incomplete_ruptures`       | `True`, **`False`**         | Whether to consider ruptures for which not all segments are selected. If ``drop_incomplete_ruptures` is `True`, the energy of incomplete ruptures (i.e. those for which any participating segment is not selected) is not distributed to the segments. This has an impact preferentially on the large magnitudes in which many segments participate, and hence the change of any rupture being unselected is high. |
| `slip_weighting`                 | **`'tapered'`**,`'uniform'` | Determines the assumed distribution of slip along the rupture (i.e. "boxcar" or "tapered"). Only has an effect if `use_slip == True`. |

## Requirements
Building the loaducerf3 package requires the following software and libraries to be installed:
- **Meson** build system
- **GMP**, The GNU Multiple Precision Arithmetic Library
- **CGAL**, The Computational Geometry Algorithms Library
- **NumPy**
- **Cython**

Optional requirements for the `loaducerf3.plottools` module are
- **Matplotlib**

When building using Meson, the following software packages are automatically downlaoded:
- **rapidxml**
- **ProjWrapCpp**

## License

The loaducerf3 package is licensed under the GNU General Public License (GPL), version 3 or (at your option) later.


## Changelog
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

### [1.1.3] - 2023-01-11
#### Changed
- Create mock source file during installation to prevent a gcc error in
  some linux variants.

### [1.1.2] - 2023-01-05
#### Added
- Add meson build option `portable` that switches off the native architecture
  instruction sets.

### [1.1.1] - 2022-11-25
#### Changed
- Switch from `ssh` connection to `https` in libprojwrap subproject.

### [1.1.0] - 2022-07-04
#### Added
- Added missing Meson build file for rapidxml

### [1.0.0] - 2022-06-30
#### Added
- First version.
