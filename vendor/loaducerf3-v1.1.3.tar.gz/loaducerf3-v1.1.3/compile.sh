#!/bin/bash
# Compilation hack.

# First check if the meson build has already been set up:
if [ ! -d builddir ]; then
    meson setup builddir
fi

# Once setup, can compile:
meson compile -C builddir