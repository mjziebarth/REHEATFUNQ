/*
 * Fault segments.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <string>
#include <vector>
#include <exception>
#include <functional>
#include <../include/types.hpp>

#ifndef LOAD_UCERF3_FAULTSEGMENT_HPP
#define LOAD_UCERF3_FAULTSEGMENT_HPP

namespace loaducerf3 {

class FaultSectionsParseError : public std::runtime_error {
public:
	FaultSectionsParseError(const char* msg);
};


/*
 * Base class holding all the attributes:
 */
class FaultSegmentBase {
public:
	FaultSegmentBase();
	FaultSegmentBase(unsigned int id, std::string name, double slip_rate_m_s,
	                 double slip_rate_std_m_s, double dip, double rake,
	                 double upper_depth_m, double lower_depth_m,
	                 double aseismic_slip_factor, double coupling,
	                 double dip_dir, std::string&& parent_name,
	                 unsigned int parent_id, bool connector);

	const std::string& name() const;
	const std::string& parent() const;
	double area() const;
	void set_area(double area);

	double slip_rate() const;

	double power() const;

	void add_power(double P);
	void add_rupture_link(unsigned int r, double w);


private:
	unsigned int id;
	std::string _name;
	double slip_rate_m_s;
	double slip_rate_std_m_s;
	double dip;
	double rake;
	double upper_depth_m;
	double lower_depth_m;
	double aseismic_slip_factor;
	double coupling;
	double dip_dir;
	std::string parent_name;
	unsigned int parent_id;
	bool connector;
	double _area;
	double _power;
	struct rupture_link {
		unsigned int r;
		double w;
	};
	std::vector<rupture_link> linked_ruptures;
};


class ProjectedFaultSegment;

class FaultSegment : public FaultSegmentBase {
	friend ProjectedFaultSegment;
public:
	typedef std::vector<geo_t>::const_iterator const_iterator;

	FaultSegment();

	FaultSegment(unsigned int id, std::string name, double slip_rate_m_s,
	             double slip_rate_std_m_s, double dip, double rake,
	             double upper_depth_m, double lower_depth_m,
	             double aseismic_slip_factor, double coupling, double dip_dir,
	             std::string&& parent_name, unsigned int parent_id,
	             bool connector, std::vector<geo_t>&& coords);

	static std::vector<FaultSegment>
	parse_xml(std::string file,
	          const std::function<bool(FaultSegment const&)>& selector
	              = FaultSegment::no_filter);


	const_iterator begin() const;
	const_iterator end() const;


private:

	std::vector<geo_t> coords;

	static bool no_filter(const FaultSegment&);
};

class Rupture;

struct rupture_contribution {
	const Rupture* rup;
	double w;
};

/*
 * A projected version of the former:
 */
class ProjectedFaultSegment : public FaultSegmentBase {
public:
	typedef std::vector<xy_t>::const_iterator const_iterator;

	ProjectedFaultSegment();
	ProjectedFaultSegment(const FaultSegment&, const ProjWrapper&);


	const_iterator begin() const;
	const_iterator end() const;
	size_t size() const;

	double length() const;


private:
	std::vector<xy_t> coords;
	std::vector<rupture_contribution> linked_ruptures;
	double _length;
};

}

#endif