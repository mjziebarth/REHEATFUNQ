/*
 * A UCERF3 fault.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <../include/faultsegment.hpp>

#ifndef LOAD_UCERF3_FAULT
#define LOAD_UCERF3_FAULT

namespace loaducerf3 {

class Fault {
public:
	Fault(const std::string& name,
	      std::vector<const ProjectedFaultSegment*>&& segments);


	inline const std::string& name() const
	{
		return _name;
	}

	inline double length() const
	{
		return _length;
	}

	inline double area() const {
		return _area;
	}

	inline double power() const {
		return _power;
	}

	inline const std::vector<xy_t>& trace() const {
		return _trace;
	}

	inline const std::vector<const ProjectedFaultSegment*>&
	segments() const
	{
		return _segments;
	}

private:
	const std::string _name;
	const std::vector<const ProjectedFaultSegment*> _segments;
	const std::vector<xy_t> _trace;
	const double _length;
	const double _area;
	const double _power;
};

}

#endif