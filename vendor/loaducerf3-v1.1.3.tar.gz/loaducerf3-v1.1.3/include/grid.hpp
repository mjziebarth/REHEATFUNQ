/*
 * Grid sources of the UCERF3 model not associated to any specific fault.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <vector>
#include <../include/types.hpp>
#include <../include/selector.hpp>
#include <stdexcept>
#include <functional>

#ifndef LOAD_UCERF3_GRID_HPP
#define LOAD_UCERF3_GRID_HPP

namespace loaducerf3 {

class GridError : public std::runtime_error {
public:
	GridError(const char* msg) : std::runtime_error(msg)
	{
	};

	GridError(std::string str) : std::runtime_error(str)
	{
	};

};


class GridSources {
public:
	GridSources(const char* relm_gridded_region_csv,
	            const char* grid_sources_bin,
	            std::function<bool(const geo_t&, const xy_t&)> selector,
	            const ProjWrapper& proj);

	double total_power() const;

private:
	/* This structure holds a magnitude-frequency distribution at a
	 * specific grid location.
	 * The size of `f` corresponds to the size of the member
	 * `GridSources::magnitudes`. */
	struct mfd_t {
		std::vector<double> f_unassociated;
		std::vector<double> f_associated;
		xy_t xy;
	};

	std::vector<mfd_t> frequencies;
	std::vector<double> magnitudes;
	std::vector<double> energies;

	struct init_mfd_t {
		std::vector<mfd_t> freqs;
		std::vector<double> magnitudes;
	};

	static init_mfd_t
	read_grid_files(const char* relm_gridded_region_csv,
	                const char* grid_sources_bin,
	                std::function<bool(const geo_t&, const xy_t&)> select,
	                const ProjWrapper& proj,
	                bool skip_header=true);

	GridSources(init_mfd_t&& init);
};

}

#endif