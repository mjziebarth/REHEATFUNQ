/*
 * Point selectors according to geometric relations.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <../include/types.hpp>
#include <../include/polygon.hpp>

#ifndef LOAD_UCERF3_SELECTOR_HPP
#define LOAD_UCERF3_SELECTOR_HPP

namespace loaducerf3 {

/*
 * "All" selector:
 */
class AllSelector {
public:
	inline bool operator()(const geo_t& point) const {
		return true;
	};
	inline bool operator()(const xy_t& point) const {
		return true;
	};
};



/*
 *    Circular selector
 */

class CircularSelector {
public:
	typedef geo_t coordinate_t;

	CircularSelector(double lon, double lat, double radius_m);
	CircularSelector(const geo_t& center, double radius_m);

	bool operator()(const geo_t& point) const;

private:
	geo_t center;
	double r_m;
};



/*
 *    Polygon selector.
 */

class PolygonSelector {
public:
	typedef xy_t coordinate_t;

	PolygonSelector();
	PolygonSelector(Polygon&& poly);
	PolygonSelector(const Polygon& poly);

	bool operator()(const xy_t& point) const;

	bool select(double x, double y) const;

private:
	Polygon poly;
	std::shared_ptr<const ProjWrapper> proj;
};





}


#endif