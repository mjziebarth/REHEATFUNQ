/*
 * Organization of the rupture data.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <vector>

#ifndef LOAD_UCERF3_RUPTURE_HPP
#define LOAD_UCERF3_RUPTURE_HPP

namespace loaducerf3 {

class Rupture {
public:
	Rupture(std::vector<unsigned int>&& sec, double mag, double rate,
	        double rup_area, double rup_len);

	static std::vector<Rupture>
	   read(const char* mags_bin, const char* rates_bin,
	        const char* rup_areas_bin, const char* rup_lenghts_bin,
	        const char* rup_sections_bin);

	const std::vector<unsigned int>& sections() const;

	double rate() const;
	double energy() const;
	double power() const;
	double magnitude() const;
	double rupture_area() const;
	double rupture_length() const;

private:
	double mag; // from mags.bin
	double _rate; // from rates.bin
	double rup_area; // from rup_areas.bin
	double rup_len; // from rup_lengths.bin
	std::vector<unsigned int> sec; // from rup_sections.bin
	double _energy;

};



}

#endif