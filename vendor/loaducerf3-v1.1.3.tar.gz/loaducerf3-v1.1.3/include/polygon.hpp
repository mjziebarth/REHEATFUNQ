/*
 * Two-dimensional polygons and containment therein.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>..
 */

#include <cstddef>
#include <exception>
#include <../include/types.hpp>

/* Use CGAL for computation: */
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>

#ifndef LOAD_UCERF3_POLYGON_HPP
#define LOAD_UCERF3_POLYGON_HPP

namespace loaducerf3 {

class PolygonError : public std::runtime_error {
public:
	PolygonError(const char* msg);
};

class Polygon {
public:
	Polygon();
	Polygon(const std::vector<xy_t>& points);
//	Polygon(std::vector<xy_t>&& points);
	Polygon(const double* x, const double* y, size_t n);

	/* Check whether point is inside or on boundary: */
	bool contains(const xy_t& point) const;

private:
	typedef CGAL::Exact_predicates_inexact_constructions_kernel  K;
	typedef CGAL::Polygon_2<K>  Polygon_2;
	typedef CGAL::Point_2<K>  Point;

	Polygon_2 poly;
	bool is_simple;
};


}


#endif