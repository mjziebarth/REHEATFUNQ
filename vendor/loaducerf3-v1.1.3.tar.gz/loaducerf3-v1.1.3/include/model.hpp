/*
 * Abstract a UCERF3 model from a specific branch.
 *
 * Copyright (C) 2022 Deutsches GeoForschungsZentrum Potsdam
 *
 * Author: Malte J. Ziebarth (ziebarth@gfz-potsdam.de)
 *
 * This file is part of loaducerf3.
 *
 * loaducerf3 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version.
 *
 * loaducerf3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with loaducerf3. If not, see <https://www.gnu.org/licenses/>.
 */

#include <memory>
#include <../include/faultsegment.hpp>
#include <../include/selector.hpp>
#include <../include/rupture.hpp>
#include <../include/fault.hpp>
#include <../include/grid.hpp>


#ifndef LOAD_UCERF3_UCERF3MODEL_HPP
#define LOAD_UCERF3_UCERF3MODEL_HPP

namespace loaducerf3 {

enum segment_selection_policy {
	ALL_IN, ANY_IN
};

enum slip_weight_type {
	TAPERED, UNIFORM
};


class UCERF3Model {
public:
	UCERF3Model(const char* fault_section_xml,
	            const char* mags_bin, const char* rates_bin,
	            const char* rup_areas_bin, const char* rup_lengths_bin,
	            const char* rup_sections_bin,
	            const char* sect_areas_bin, const char* grid_sources_bin,
	            const char* relm_gridded_region_csv,
	            std::shared_ptr<const ProjWrapper> proj,
	            bool use_slip, bool use_area,
	            bool consider_intersegment_distance,
	            slip_weight_type slip_weighting);

	UCERF3Model(const char* faultsection_xml,
	            const char* mags_bin, const char* rates_bin,
	            const char* rup_areas_bin, const char* rup_lengths_bin,
	            const char* rup_sections_bin,
	            const char* sect_areas_bin, const char* grid_sources_bin,
	            const char* relm_gridded_region_csv,
	            const CircularSelector& selector,
	            std::shared_ptr<const ProjWrapper> proj,
	            segment_selection_policy ssp,
	            bool use_slip, bool use_area,
	            bool consider_intersegment_distance,
	            bool consider_masked_segments,
	            bool drop_incomplete_ruptures,
	            slip_weight_type slip_weighting);

	UCERF3Model(const char* faultsection_xml,
	            const char* mags_bin, const char* rates_bin,
	            const char* rup_areas_bin, const char* rup_lengths_bin,
	            const char* rup_sections_bin,
	            const char* sect_areas_bin, const char* grid_sources_bin,
	            const char* relm_gridded_region_csv,
	            const PolygonSelector& selector,
	            std::shared_ptr<const ProjWrapper> proj,
	            segment_selection_policy ssp,
	            bool use_slip, bool use_area,
	            bool consider_intersegment_distance,
	            bool consider_masked_segments,
	            bool drop_incomplete_ruptures,
	            slip_weight_type slip_weighting);

	const std::vector<ProjectedFaultSegment>& segments() const;
	const std::vector<Fault>& faults() const;

	double total_power() const;

	const ProjWrapper& projection() const;

private:
	std::shared_ptr<const ProjWrapper> proj;
	std::vector<Rupture> ruptures;
	std::vector<ProjectedFaultSegment> _segments;
	std::vector<Fault> _faults;
	GridSources grdsrc;
	double _total_power;

	double compute_total_power() const;

	void initialize_faults();
};

}

#endif